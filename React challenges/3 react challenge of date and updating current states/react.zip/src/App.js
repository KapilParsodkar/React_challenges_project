import "./styles.css";
import {useState} from "react"

export default function App() {
  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
        <Counter/>
    </div>
  );
}

function Counter(){
    const [step,setstep]=useState(1)
    const [count,setcount]=useState(0)
    const date=new Date("july 22 2023")
    date.setDate(date.getDate()+count)
      return(
           <div>
             <diV>
               <button onClick={()=>setcount((c)=>c-step)}>-</button>
               <span>count {count}</span>
               <button onClick={()=>setcount((c)=>c+step)}>+</button>
             </diV>
             <diV>
               <button onClick={()=>setstep((c)=>c-1)}>-</button>
               <span>step {step}</span>
               <button onClick={()=>setstep((c)=>c+1)}>+</button>
             </diV>
             <span>
             {
               count===0?"today is ":count>0?`${count} days from today will be `:`${Math.abs(count)} days ago was`
             }
             </span>
             <span>{date.toDateString()}</span>
           </div>
      )
}